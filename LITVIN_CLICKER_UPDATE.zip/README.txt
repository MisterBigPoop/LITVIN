# LITVIN CLICKER update

## Files
- `app/src/main/java/com/zov/litvinclicker/MainActivity.kt`
- `app/src/main/res/drawable-nodpi/snow_bg.jpg`
- `app/src/main/res/drawable-nodpi/litvin_photo.jpg`

Copy these files into the same paths in your GitHub repository, replacing the old `MainActivity.kt`.

The screen uses your supplied snowy village photo as the background and your supplied portrait photo in a clickable portrait panel. It includes click power, auto income, a daily 250-coin bonus, a 5-minute x2 boost, level and record counters, and saves progress locally.

The photo is used as a rectangular portrait panel, not a transparent cutout. The build has not been run in GitHub Actions yet; upload the files and check the Actions result.
