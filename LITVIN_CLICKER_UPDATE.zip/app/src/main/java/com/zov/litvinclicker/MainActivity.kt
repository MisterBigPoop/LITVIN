package com.zov.litvinclicker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Purple = Color(0xFF9C35FF)
private val Gold = Color(0xFFFFC928)
private val Panel = Color(0xE9100B2C)
private val White = Color(0xFFF8F6FF)
private val Muted = Color(0xFFCBC5E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 5894 or 1024 or 512

        val prefs = getSharedPreferences("litvin_clicker", MODE_PRIVATE)
        setContent {
            var coins by remember { mutableLongStateOf(prefs.getLong("coins", 0L)) }
            var power by remember { mutableIntStateOf(prefs.getInt("power", 1)) }
            var auto by remember { mutableIntStateOf(prefs.getInt("auto", 0)) }
            var taps by remember { mutableLongStateOf(prefs.getLong("taps", 0L)) }
            var record by remember { mutableLongStateOf(prefs.getLong("record", 0L)) }
            var boostUntil by remember { mutableLongStateOf(prefs.getLong("boost_until", 0L)) }
            var lastDaily by remember { mutableStateOf(prefs.getString("daily_date", "") ?: "") }
            var pulse by remember { mutableIntStateOf(0) }

            val powerCost = 100L * power
            val autoCost = 500L * (auto + 1)
            val superCost = 1000L * (power + auto + 1)
            val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
            val boostActive = System.currentTimeMillis() < boostUntil
            val level = (coins / 100L + 1L).coerceAtMost(9999L)

            fun save() {
                prefs.edit()
                    .putLong("coins", coins)
                    .putInt("power", power)
                    .putInt("auto", auto)
                    .putLong("taps", taps)
                    .putLong("record", record)
                    .putLong("boost_until", boostUntil)
                    .putString("daily_date", lastDaily)
                    .apply()
            }

            fun addCoins(amount: Long) {
                coins += amount
                if (coins > record) record = coins
                save()
            }

            LaunchedEffect(Unit) {
                while (true) {
                    delay(1000)
                    if (auto > 0) {
                        val multiplier = if (System.currentTimeMillis() < boostUntil) 2L else 1L
                        addCoins(auto.toLong() * multiplier)
                    }
                }
            }

            MaterialTheme {
                Box(Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(R.drawable.snow_bg),
                        contentDescription = "Зимняя деревня ночью",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xE8090820),
                                    Color(0x66100B2B),
                                    Color(0x55100B2B),
                                    Color(0xE8090820)
                                )
                            )
                        )
                    )
                    SnowOverlay()

                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // LEFT SHOP
                        Column(
                            Modifier.weight(0.30f).fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Text("🛒  МАГАЗИН", color = White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                            UpgradeCard("Сила клика", "+$power монета за клик", "Уровень: $power", powerCost, coins) {
                                if (coins >= powerCost) { coins -= powerCost; power++; save() }
                            }
                            UpgradeCard("Автокликер", "+1 монета/сек", "Уровень: $auto", autoCost, coins) {
                                if (coins >= autoCost) { coins -= autoCost; auto++; save() }
                            }
                            UpgradeCard("Усиление клика", "+10 монет за клик", "Уровень: ${power / 10}", superCost, coins) {
                                if (coins >= superCost) { coins -= superCost; power += 10; save() }
                            }
                            Spacer(Modifier.weight(1f))
                            ActionPanel(
                                title = "🎁  Ежедневный бонус",
                                detail = if (lastDaily == today) "Уже получен сегодня" else "Забери 250 монет!",
                                enabled = lastDaily != today,
                                onClick = {
                                    if (lastDaily != today) {
                                        lastDaily = today
                                        addCoins(250L)
                                    }
                                }
                            )
                        }

                        // CENTER GAME AREA
                        Column(
                            Modifier.weight(0.43f).fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "LITVIN CLICKER",
                                color = Color(0xFFCE65FF),
                                fontSize = 27.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp
                            )
                            Row(
                                Modifier.padding(top = 2.dp).clip(CircleShape)
                                    .background(Panel).border(1.dp, Color(0x88FFD34D), CircleShape)
                                    .padding(horizontal = 16.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🪙  ", fontSize = 16.sp)
                                Text("%,d".format(coins), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                Text("  МОНЕТ", color = White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            Box(
                                Modifier.weight(1f).fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.litvin_photo),
                                    contentDescription = "Фото персонажа для клика",
                                    modifier = Modifier
                                        .fillMaxHeight(0.94f)
                                        .widthIn(max = 330.dp)
                                        .aspectRatio(0.72f)
                                        .shadow(18.dp, RoundedCornerShape(26.dp))
                                        .clip(RoundedCornerShape(26.dp))
                                        .border(2.dp, Color(0xCCB84DFF), RoundedCornerShape(26.dp))
                                        .clickable {
                                            val multiplier = if (System.currentTimeMillis() < boostUntil) 2L else 1L
                                            addCoins(power.toLong() * multiplier)
                                            taps++
                                            pulse++
                                            save()
                                        },
                                    contentScale = ContentScale.Crop,
                                    alignment = Alignment.TopCenter
                                )
                                // The click prompt is a separate live button over the lower part of the photo.
                                Box(
                                    Modifier.align(Alignment.BottomCenter)
                                        .padding(bottom = 3.dp)
                                        .shadow(12.dp, RoundedCornerShape(50))
                                        .clip(RoundedCornerShape(50))
                                        .background(Brush.horizontalGradient(listOf(Color(0xFF4A00B5), Purple, Color(0xFF4A00B5))))
                                        .border(1.dp, Color(0xFFFFB7FF), RoundedCornerShape(50))
                                        .clickable {
                                            val multiplier = if (System.currentTimeMillis() < boostUntil) 2L else 1L
                                            addCoins(power.toLong() * multiplier)
                                            taps++
                                            pulse++
                                            save()
                                        }
                                        .padding(horizontal = 34.dp, vertical = 9.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("⚡ НАЖМИ! ⚡", color = White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                            }
                            Text("👆 Нажатий: $taps", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // RIGHT STATS
                        Column(
                            Modifier.weight(0.25f).fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(9.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(" ", fontSize = 21.sp)
                            StatCard("▮▮▮   Уровень", "$level")
                            StatCard("⚡  Доход", "${auto}/сек")
                            StatCard("👑  Твой рекорд", "%,d".format(record))
                            Spacer(Modifier.weight(1f))
                            ActionPanel(
                                title = if (boostActive) "⚡ Бонус x2 активен" else "▶  Бонус x2",
                                detail = if (boostActive) "Осталось ${((boostUntil - System.currentTimeMillis()).coerceAtLeast(0L) / 60000L) + 1} мин." else "На 5 минут",
                                enabled = !boostActive,
                                onClick = {
                                    if (!boostActive) {
                                        boostUntil = System.currentTimeMillis() + 5 * 60 * 1000L
                                        save()
                                    }
                                }
                            )
                            Text(
                                if (boostActive) "МОНЕТЫ УДВАИВАЮТСЯ" else "СИЛА: $power  •  АВТО: $auto/СЕК",
                                color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpgradeCard(
    title: String,
    detail: String,
    level: String,
    cost: Long,
    coins: Long,
    onBuy: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
            .background(Panel).border(1.dp, Color(0xAA842DDB), RoundedCornerShape(13.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(title, color = White, fontSize = 14.sp, fontWeight = FontWeight.Black)
        Text(detail, color = Muted, fontSize = 10.sp)
        Text(level, color = Color(0xFFBA5CFF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        val enabled = coins >= cost
        Box(
            Modifier.fillMaxWidth().height(31.dp).clip(RoundedCornerShape(9.dp))
                .background(if (enabled) Brush.horizontalGradient(listOf(Color(0xFF9D35FF), Color(0xFF5D13CF))) else Brush.horizontalGradient(listOf(Color(0xFF35304B), Color(0xFF27243B))))
                .clickable(enabled = enabled, onClick = onBuy),
            contentAlignment = Alignment.Center
        ) {
            Text("🪙  ${"%,d".format(cost)}", color = White, fontSize = 12.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun StatCard(title: String, value: String) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
            .background(Panel).border(1.dp, Color(0xAA842DDB), RoundedCornerShape(13.dp))
            .padding(11.dp)
    ) {
        Text(title, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(value, color = if (title.contains("рекорд")) Gold else White, fontSize = 19.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun ActionPanel(title: String, detail: String, enabled: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
            .background(Panel).border(1.dp, Color(0xAA842DDB), RoundedCornerShape(13.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(10.dp)
    ) {
        Text(title, color = White, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Text(detail, color = if (enabled) Gold else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SnowOverlay() {
    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
        // Static tiny snow sparkle layer; game UI stays responsive above it.
        for (i in 0 until 70) {
            val x = ((i * 137) % 997) / 997f * size.width
            val y = ((i * 263) % 991) / 991f * size.height
            drawCircle(Color.White.copy(alpha = 0.18f), radius = if (i % 4 == 0) 2.0f else 1.0f, center = androidx.compose.ui.geometry.Offset(x, y))
        }
    }
}
