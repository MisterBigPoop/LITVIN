package com.zov.litvinclicker
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.decorView.systemUiVisibility = 5894 or 1024 or 512
  val prefs=getSharedPreferences("game", MODE_PRIVATE)
  setContent {
   var coins by remember { mutableLongStateOf(prefs.getLong("coins",0L)) }
   var power by remember { mutableIntStateOf(prefs.getInt("power",1)) }
   var auto by remember { mutableIntStateOf(prefs.getInt("auto",0)) }
   var taps by remember { mutableIntStateOf(0) }
   var pulse by remember { mutableIntStateOf(0) }
   val powerCost=25L*power
   val autoCost=100L*(auto+1)
   LaunchedEffect(Unit) { while(true) { delay(1000); if(auto>0) coins+=auto.toLong() } }
   LaunchedEffect(coins,power,auto) { prefs.edit().putLong("coins",coins).putInt("power",power).putInt("auto",auto).apply() }
   MaterialTheme {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF10142D),Color(0xFF28164B),Color(0xFF090D1D))))) {
     Snow()
     Row(Modifier.fillMaxSize().padding(14.dp), horizontalArrangement=Arrangement.spacedBy(14.dp)) {
      Column(Modifier.weight(.28f).fillMaxHeight(), verticalArrangement=Arrangement.spacedBy(10.dp)) {
       Text("МАГАЗИН",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Black)
       Upgrade("СИЛА КЛИКА","+${power} монет за нажатие",powerCost,coins) { if(coins>=powerCost){coins-=powerCost;power++} }
       Upgrade("АВТОКЛИК","+1 монета/сек",autoCost,coins) { if(coins>=autoCost){coins-=autoCost;auto++} }
       Spacer(Modifier.weight(1f))
       Text("Сила: $power • Авто: $auto/сек",color=Color.LightGray,fontSize=12.sp)
      }
      Column(Modifier.weight(.72f).fillMaxHeight(),horizontalAlignment=Alignment.CenterHorizontally) {
       Text("LITVIN CLICKER",color=Color(0xFFFFD86B),fontSize=26.sp,fontWeight=FontWeight.Black)
       Text("МОНЕТЫ: $coins",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold)
       Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) {
        Box(Modifier.size(if(pulse%2==0)190.dp else 184.dp).background(Brush.radialGradient(listOf(Color(0xFFFFD86B),Color(0xFFB64CFF))),RoundedCornerShape(100.dp)).clickable { coins+=power; taps++; pulse++ },contentAlignment=Alignment.Center) {
         Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("Л",fontSize=76.sp,color=Color(0xFF24113C),fontWeight=FontWeight.Black); Text("НАЖМИ!",color=Color(0xFF24113C),fontWeight=FontWeight.Black) }
        }
       }
       Text("Нажатий: $taps",color=Color.LightGray,fontSize=13.sp)
      }
     }
    }
   }
  }
 }
}
@Composable private fun Upgrade(title:String,detail:String,cost:Long,coins:Long,onBuy:()->Unit) {
 Column(Modifier.fillMaxWidth().background(Color(0xCC25264A),RoundedCornerShape(14.dp)).padding(10.dp)) {
  Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp)
  Text(detail,color=Color(0xFFC9C5E8),fontSize=11.sp)
  Spacer(Modifier.height(6.dp))
  Button(onClick=onBuy,enabled=coins>=cost,contentPadding=PaddingValues(horizontal=8.dp,vertical=4.dp)){Text("Купить • $cost",fontSize=11.sp)}
 }
}
@Composable private fun Snow() {
 val flakes=remember { List(55){Offset(Random.nextFloat(),Random.nextFloat())} }
 var tick by remember { mutableIntStateOf(0) }
 LaunchedEffect(Unit){while(true){delay(55);tick++}}
 Canvas(Modifier.fillMaxSize()) { flakes.forEachIndexed { i,p -> val y=(p.y+tick*(.0015f+(i%5)*.00035f))%1f; drawCircle(Color.White.copy(alpha=.35f),1.5f+(i%3),Offset(p.x*size.width,y*size.height)) } }
}
