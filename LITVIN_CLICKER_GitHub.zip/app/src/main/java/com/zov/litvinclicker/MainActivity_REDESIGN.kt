package com.zov.litvinclicker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Night = Color(0xFF090B1B)
private val Panel = Color(0xDD191D3B)
private val Gold = Color(0xFFFFD66B)
private val Muted = Color(0xFFB9BED8)
private val Purple = Color(0xFF9D4DFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            5894 or 1024 or 512

        val prefs = getSharedPreferences("game", MODE_PRIVATE)
        setContent {
            var coins by remember { mutableLongStateOf(prefs.getLong("coins", 0L)) }
            var power by remember { mutableIntStateOf(prefs.getInt("power", 1)) }
            var auto by remember { mutableIntStateOf(prefs.getInt("auto", 0)) }
            var taps by remember { mutableIntStateOf(prefs.getInt("taps", 0)) }
            var tapPulse by remember { mutableIntStateOf(0) }

            val powerCost = 25L * power
            val autoCost = 100L * (auto + 1)

            LaunchedEffect(Unit) {
                while (true) {
                    delay(1000)
                    if (auto > 0) coins += auto.toLong()
                }
            }

            LaunchedEffect(coins, power, auto, taps) {
                prefs.edit()
                    .putLong("coins", coins)
                    .putInt("power", power)
                    .putInt("auto", auto)
                    .putInt("taps", taps)
                    .apply()
            }

            MaterialTheme {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF10152F),
                                    Color(0xFF21133F),
                                    Night
                                )
                            )
                        )
                ) {
                    Snowfall()

                    Row(
                        Modifier
                            .fillMaxSize()
                            .padding(horizontal = 22.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(22.dp)
                    ) {
                        // LEFT: upgrade shop
                        Column(
                            Modifier
                                .weight(0.34f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("МАГАЗИН", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                                Text("UPGRADES", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }

                            UpgradeCard(
                                title = "СИЛА КЛИКА",
                                subtitle = "Каждое нажатие приносит больше монет",
                                level = "УРОВЕНЬ $power",
                                price = powerCost,
                                canBuy = coins >= powerCost,
                                accent = Gold,
                                onBuy = {
                                    if (coins >= powerCost) {
                                        coins -= powerCost
                                        power++
                                    }
                                }
                            )

                            UpgradeCard(
                                title = "АВТОКЛИК",
                                subtitle = "Монеты начисляются автоматически",
                                level = "УРОВЕНЬ $auto",
                                price = autoCost,
                                canBuy = coins >= autoCost,
                                accent = Color(0xFF64E8D2),
                                onBuy = {
                                    if (coins >= autoCost) {
                                        coins -= autoCost
                                        auto++
                                    }
                                }
                            )

                            Spacer(Modifier.weight(1f))

                            Text(
                                "ТВОИ УЛУЧШЕНИЯ",
                                color = Muted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MiniStat("КЛИК", "+$power", Modifier.weight(1f))
                                MiniStat("АВТО", "${auto}/сек", Modifier.weight(1f))
                            }
                        }

                        // RIGHT: game area
                        Column(
                            Modifier
                                .weight(0.66f)
                                .fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "LITVIN CLICKER",
                                color = Gold,
                                fontSize = 29.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp
                            )
                            Row(
                                Modifier
                                    .padding(top = 5.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color(0xAA11152D))
                                    .border(1.dp, Color(0x55FFD66B), RoundedCornerShape(50))
                                    .padding(horizontal = 18.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🪙", fontSize = 17.sp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "%,d".format(coins),
                                    color = Color.White,
                                    fontSize = 21.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text("  МОНЕТ",
                                    color = Muted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Box(
                                Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                // Soft glow behind the main button
                                Box(
                                    Modifier
                                        .size(260.dp)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(
                                                    Color(0x559D4DFF),
                                                    Color(0x229D4DFF),
                                                    Color.Transparent
                                                )
                                            ),
                                            CircleShape
                                        )
                                )

                                Box(
                                    Modifier
                                        .size(if (tapPulse % 2 == 0) 206.dp else 198.dp)
                                        .shadow(24.dp, CircleShape)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                listOf(
                                                    Color(0xFFFFE69A),
                                                    Color(0xFFFFB84D),
                                                    Color(0xFFB94EFF),
                                                    Color(0xFF8B42E8)
                                                )
                                            )
                                        )
                                        .border(4.dp, Color(0xAAFFFFFF), CircleShape)
                                        .clickable {
                                            coins += power
                                            taps++
                                            tapPulse++
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            "Л",
                                            color = Color(0xFF24113D),
                                            fontSize = 82.sp,
                                            lineHeight = 84.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Text(
                                            "НАЖМИ!",
                                            color = Color(0xFF24113D),
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Black,
                                            letterSpacing = 1.5.sp
                                        )
                                        Text(
                                            "+$power 🪙",
                                            color = Color(0xFF38204F),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("👆  НАЖАТИЙ: $taps", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("⚡  ДОХОД: ${auto}/СЕК", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpgradeCard(
    title: String,
    subtitle: String,
    level: String,
    price: Long,
    canBuy: Boolean,
    accent: Color,
    onBuy: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .background(Panel)
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(18.dp))
            .padding(13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(accent)
            )
            Spacer(Modifier.width(7.dp))
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Text(level, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
        Spacer(Modifier.height(12.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .height(39.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(
                    if (canBuy) Brush.horizontalGradient(listOf(accent, Color(0xFFE9A8FF)))
                    else Brush.horizontalGradient(listOf(Color(0xFF343751), Color(0xFF292D46)))
                )
                .clickable(enabled = canBuy, onClick = onBuy),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (canBuy) "КУПИТЬ  •  $price 🪙" else "НУЖНО  •  $price 🪙",
                color = if (canBuy) Color(0xFF211333) else Color(0xFFB9BED8),
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x99191D3B))
            .padding(horizontal = 11.dp, vertical = 8.dp)
    ) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun Snowfall() {
    val flakes = remember {
        List(65) {
            Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 2.2f + 1f)
        }
    }
    var frame by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(45)
            frame++
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        flakes.forEachIndexed { index, flake ->
            val x = flake.first * size.width
            val y = (flake.second * size.height + frame * (0.35f + (index % 5) * 0.13f)) % size.height
            drawCircle(
                color = Color.White.copy(alpha = 0.18f + (index % 4) * 0.08f),
                radius = flake.third,
                center = Offset(x, y)
            )
        }
    }
}
