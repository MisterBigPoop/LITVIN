# LITVIN CLICKER

Native Android Kotlin + Jetpack Compose clicker project.

- Landscape orientation
- Android compile SDK 35, min SDK 23
- Java/Kotlin JVM target 17
- GitHub Actions workflow builds a debug APK

Upload this ZIP and `LITVIN_CLICKER_UPDATE.zip` to the repository root. The workflow extracts the base project first and then overlays the updated game screen and image resources.
